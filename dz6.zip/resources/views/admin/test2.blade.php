@extends('layouts.app')

@section('title')
    @parent test2
@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <h1>test2</h1>
@endsection
