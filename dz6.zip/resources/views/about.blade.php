@extends('layouts.app')

@section('title')
    @parent О проекте
@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
    <h1>О проекте</h1>
@endsection
