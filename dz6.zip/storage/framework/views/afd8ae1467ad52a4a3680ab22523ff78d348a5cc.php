<?php $__env->startSection('title'); ?>
    <?php if(!$category->id): ?>
        <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Добавить категорию
    <?php else: ?>
        <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Изменить категорию
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1>
                        <?php if(!$category->id): ?>
                            Добавить категорию
                        <?php else: ?>
                            Изменить категорию
                        <?php endif; ?>
                    </h1>
                </div>
                <div class="card-body">
                    <form class="needs-validation" method="POST"
                        action="<?php if(!$category->id): ?> <?php echo e(route('admin.categories.store')); ?> <?php else: ?> <?php echo e(route('admin.categories.update', $category)); ?> <?php endif; ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if($category->id): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row mb-3">
                            <label for="inputNewsTitle" class="col-md-4 col-form-label text-md-end">Категория</label>

                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" id="inputNewsTitle"
                                    value="<?php echo e(old('name') ?? $category->name); ?>" required autofocus>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php if($category->id): ?>
                                        <?php echo e(__('Изменить')); ?>

                                    <?php else: ?>
                                        <?php echo e(__('Добавить')); ?>

                                    <?php endif; ?>
                                    категорию
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>