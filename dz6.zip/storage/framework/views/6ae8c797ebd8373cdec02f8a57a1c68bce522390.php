<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Новость
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($news): ?>
        <div class="card">
            <img src="<?php echo e($news->image ?? asset('/storage/img/default.jpg')); ?>" class="card-img-top" alt="news picture">
            <div class="card-body">
                <h2 class="card-title"><?php echo e($news->title); ?></h2>
                <?php if(!$news->isPrivate): ?>
                    <p class="card-text"><?php echo e($news->text); ?></p>
                <?php else: ?>
                    <p class="card-text">Зарегистрируйтесь для просмотра</p>
                <?php endif; ?>
            </div>
            <form action="<?php echo e(route('admin.news.destroy', $news)); ?>" method="post">
                <a class="btn btn-outline-primary" href="<?php echo e(route('admin.news.edit', $news)); ?>">Редактировать</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-outline-primary">Удалить</button>
            </form>
        </div>
    <?php else: ?>
        <h2>Такой новости нет</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/admin/news/one.blade.php ENDPATH**/ ?>