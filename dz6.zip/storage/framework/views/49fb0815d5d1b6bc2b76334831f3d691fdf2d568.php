<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('main') ? 'text-bg-secondary' : ''); ?>"
        href="<?php echo e(route('main')); ?>"><strong>Главная</strong></a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('news.categories') ? 'text-bg-secondary' : ''); ?>"
        href="<?php echo e(route('news.categories')); ?>"><strong>Новости</strong></a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('about') ? 'text-bg-secondary' : ''); ?>" href="<?php echo e(route('about')); ?>"><strong>О
            проекте</strong></a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('admin.index') ? 'text-bg-secondary' : ''); ?>"
        href="<?php echo e(route('admin.index')); ?>"><strong>Админка</strong></a>
</li>
<?php /**PATH /var/www/html/resources/views/menu.blade.php ENDPATH**/ ?>