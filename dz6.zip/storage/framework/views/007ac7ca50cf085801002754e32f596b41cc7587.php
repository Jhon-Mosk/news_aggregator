<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Добавить новость
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1>Добавить новость</h1>
                </div>

                <div class="card-body">
                    <form class="needs-validation" method="POST" action="<?php echo e(route('admin.createNews')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="inputNewsTitle" class="col-md-4 col-form-label text-md-end">Заголовок</label>

                            <div class="col-md-6">
                                <input type="text" name="title" class="form-control" id="inputNewsTitle"
                                    value="<?php echo e(old('title')); ?>" required autofocus>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="inputNewsCategory" class="col-md-4 col-form-label text-md-end">Категория</label>

                            <div class="col-md-6">
                                <select name="category_id" class="form-select" id="inputNewsCategory" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option <?php if($category['id'] == old('category_id')): ?> selected <?php endif; ?>
                                            value="<?php echo e($category['id']); ?>">
                                            <?php echo e($category['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p>Категории осутствуют</p>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="inputNewsText" class="col-md-4 col-form-label text-md-end">Текст</label>
                            <div class="col-md-6">
                                <textarea name="text" class="form-control" id="inputNewsText" rows="3" required><?php echo e(old('text')); ?></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="inputLoadImage" class="col-md-4 col-form-label text-md-end">Загрузить
                                изображение</label>
                            <div class="col-md-6">
                                <input type="file" accept="image/png, image/jpeg" name="image" class="form-control"
                                    id="inputLoadImage" rows="3">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-md-4 form-check-label text-md-end" for="inputNewsIsPrivate">Приватная</label>
                            <div class="col-md-6">
                                <div class="form-check form-switch">
                                    <input <?php if(old('isPrivate')): ?> checked <?php endif; ?> name="isPrivate"
                                        class="form-check-input" type="checkbox" role="switch" id="inputNewsIsPrivate"
                                        value="1">
                                </div>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Добавить
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/createNews.blade.php ENDPATH**/ ?>