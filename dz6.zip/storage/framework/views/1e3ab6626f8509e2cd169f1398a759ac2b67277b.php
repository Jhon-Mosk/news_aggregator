<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Новости
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($category->name ?? 'Такой категории нет'); ?></h1>
    <div class="list-group">
        <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <ul class="list-group">
                <li class="list-group-item">
                    <a class="list-group-item list-group-item-action"
                        href="<?php echo e(route('admin.news.oneNews', [$category->slug, $item->slug])); ?>">
                        <?php echo e($item->title); ?>

                    </a>
                    <form action="<?php echo e(route('admin.news.destroy', $item)); ?>" method="post">
                        <a class="btn" href="<?php echo e(route('admin.news.edit', $item)); ?>">Редактировать</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn">Удалить</button>
                    </form>
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Нет новостей</p>
        <?php endif; ?>

        <div class="mt-5">
            <?php echo e($news->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/admin/news/category.blade.php ENDPATH**/ ?>